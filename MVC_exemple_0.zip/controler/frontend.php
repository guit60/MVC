<?php
require('model/frontend.php');
function listPosts()
{
	$posts = getPosts();
	require('view/listPostsView.php');
}
function post()
{
	$post = getPost($_GET['id']);
	require('view/postView.php');
	
}

?>
