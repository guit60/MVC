<?php
function getPost($postId)
{
	$db = dbConnect();
	$req = $db->prepare('SELECT id, title, content FROM posts WHERE id = ?');
	$req->execute(array($postId));
	$post = $req->fetch();
	return $post;
}

function getPosts()
{
	$db = dbconnect();
	$req = $db->query('SELECT id, title, content FROM posts');
	return $req;
}
function dbConnect()
{
	try
	{
		$db = new PDO('mysql:host=localhost;dbname=base_tuto_MVC;charset=utf8', 'magna', 'magna');
		return $db;
	}
	catch(Exception $e)
	{
		die("Erreur : ". $e->getMessage());
	}
}
?>
