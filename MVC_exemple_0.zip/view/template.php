<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="public/css/style.css" /> 
	</head>
	<body>
		<?= $content; ?>
	</body>
</html>
